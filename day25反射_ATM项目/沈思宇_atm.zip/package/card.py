
class Card:
	def __init__(self,cardid,password,money):
		self.cardid = cardid
		self.password = password
		self.money = money
		# 默认卡是不锁定的 False
		self.islock = False










